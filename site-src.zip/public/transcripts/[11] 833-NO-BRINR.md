**833-NO-BRINR** 

Note: Unlike other transcripts, this isn't a video, but the voicemail for the number (833) 662-7467.

Transcript:

| Timestamp | Info                    | Brine Ad                                                               | Reaching Spaces Ad                            | Code                                               |
|:---------:|:------------------------|:-----------------------------------------------------------------------|:----------------------------------------------|:---------------------------------------------------|
|           |                         | **[Mr. Pickles]** Hey!                                                 |                                               |                                                    |
|           |                         | **[Mr. Pickles]** Oh, H-hey! Hoh hoh hoh, have I got a deal for – you. |                                               |                                                    |
|           |                         | **[Mr. Pickles]** Premium Triple-A briii-------n-ne---                 |                                               |                                                    |
|           |                         | **[Mr. Pickles]** S-crrrrruuurururrurruuurrrrrrrr-nn – daaaaaaaaahhhh  |                                               |                                                    |
|           |                         | **[Mr. Pickles]** ppreeeeeeeeemmmmmmiiiiiiiiuuuuuuuuummmmmmmmm         |                                               |                                                    |
|           | *music starts playing*  |                                                                        |                                               |                                                    |
|           |                         |                                                                        | **[Unknown Man]** Well howdy.                 |                                                    |
|           |                         |                                                                        |                                               | **[TTS Voice]** FOUR beep                          |
|           |                         |                                                                        | **[Unknown Man]** How’s your life been?       |                                                    |
|           |                         |                                                                        |                                               | **[TTS Voice]** THREE beep                         |
|           |                         |                                                                        | **[Unknown Man]** Where did you go from here? |                                                    |
|           |                         |                                                                        |                                               | **[TTS Voice]** ONE beep beep                      |
|           |                         |                                                                        | **[Unknown Man]** Right… right f-f-fa-ast…    |                                                    |
|           |                         |                                                                        |                                               | **[TTS Voice]** THREE beep beep beep SIX beep beep |
|           |                         |                                                                        | **[Unknown Man]** Find comfort in t-the loss  |                                                    |
|           |                         |                                                                        |                                               | **[TTS Voice]** EIGHT beep SIX beep beep beep      |
|           |                         |                                                                        | **[Unknown Man]** We are b-b-but entropy      |                                                    |
|           |                         |                                                                        |                                               | **[TTS Voice]** FIVE beep beep                     |
|           |                         |                                                                        | **[Unknown Man]** Consider yourself-          |                                                    |
|           |                         |                                                                        |                                               | **[TTS Voice]** TWO beep beep                      |
|           |                         |                                                                        | **[Unknown Man]** -ightning                   |                                                    |
|           |                         |                                                                        |                                               | **[TTS Voice]** ZERO beep ONE beep                 |
|           |                         |                                                                        | **[Unknown Man]** -here you’re going…         |                                                    |
|           |                         |                                                                        | **[Unknown Man]** -that’s not up to you…      |                                                    |
|           |                         |                                                                        |                                               | **[TTS Voice]** THREE beep beep beep               |
|           |                         |                                                                        | **[Unknown Man]** Your eyes…                  |                                                    |
|           |                         |                                                                        |                                               | **[TTS Voice]** ONE beep                           |
|           |                         |                                                                        | **[Unknown Man]** ???                         |                                                    |
|           |                         |                                                                        | **[Unknown Man]** now…                        |                                                    |
|           |                         |                                                                        |                                               | **[TTS Voice]** TWO beep beep                      |
|           |                         |                                                                        | **[Unknown Man]** We’re listening.            |                                                    |
|           |                         |                                                                        |                                               | **[TTS Voice]** THREE beep beep                    |
|           |                         |                                                                        | **[Unknown Man]** *groaning?*                 |                                                    |
|           |                         |                                                                        |                                               | **[TTS Voice]** FIVE (or NINE) beep                |
|           |                         | **[Mr. Pickles]** Hey!                                                 |                                               |                                                    |
|           |                         |                                                                        |                                               | **[TTS Voice]** FIVE beep                          |
|           |                         | **[Mr. Pickles]** Oh, H-hey!                                           |                                               |                                                    |
|           |                         |                                                                        |                                               | **[TTS Voice]** NINE beep                          |
|           |                         | **[Mr. Pickles]** Hoh hoh hoh, have I got a deal for –                 |                                               |                                                    |
|           |                         |                                                                        |                                               | **[TTS Voice]** FOUR beep                          |
|           |                         | **[Mr. Pickles]** -you.                                                |                                               |                                                    |
|           |                         | **[Mr. Pickles]** Preeeemium trip-ple-A briiiiii-                      |                                               |                                                    |
|           |                         |                                                                        |                                               | **[TTS Voice]** FIVE beep beep                     |
|           |                         | **[Mr. Pickles]** -iiiiii-----iiii-----nn-ne                           |                                               |                                                    |
|           | *glitching sounds*      |                                                                        |                                               |                                                    |
|           | *end of voicemail beep* |                                                                        |                                               |                                                    |
